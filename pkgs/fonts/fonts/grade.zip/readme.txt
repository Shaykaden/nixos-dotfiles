These fonts are free, they always have been and they always will be.

All fonts were created between 1998 and 2000 by Dave Kellam and/or Brian Stuparyk using a collection of software including Paint, Photoshop, Streamline, Illustrator and Fontographer.

If you want to use any of these faces for commercial work, that's cool.  Honestly, if you do... we'd love to hear from you and or get a sample of your product.

Dave Kellam is online at eightface.com
Brian Stuparyk eschews modern technology